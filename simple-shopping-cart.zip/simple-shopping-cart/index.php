<?php 
   error_reporting(0);
   session_start();
   //session_destroy();
   $connect = mysqli_connect("localhost", "root", "", "da");
   ?>
<!DOCTYPE html>
<html>
   <head>
      </script>
      <title>Add Cart</title>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
   </head>
   <body>
      <br />
      <div class="container">
         <br />
         <br />
         <br />
         <h3 align="center">ADD TO CART <a href="add.php"><img src="images/1.png" style="width:80px;">	<?php
            if(isset($_POST["add_to_cart"]))
            {
            // $_SESSION['shopping_cart']=1;
            // if(isset($_SESSION["shopping_cart"])){
         
            // $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
            $count = count($_SESSION["shopping_cart"]);if($count){$count=$count;}else{$count=0;}
               
               $item_array = array(
                  'item_id'         => $_GET["id"],
                  'item_name'       => $_POST["hidden_name"],
                  'item_price'      => $_POST["hidden_price"],
                  'item_quantity'      => $_POST["quantity"]
               );
               $_SESSION["shopping_cart"][$count] = $item_array;
            
            
            // if(!in_array($_GET["id"], $item_array_id))
            // {
            // 	$count = count($_SESSION["shopping_cart"]);
            	
            // 	$item_array = array(
            // 		'item_id'			=>	$_GET["id"],
            // 		'item_name'			=>	$_POST["hidden_name"],
            // 		'item_price'		=>	$_POST["hidden_price"],
            // 		'item_quantity'		=>	$_POST["quantity"]
            // 	);
            // 	$_SESSION["shopping_cart"][$count] = $item_array;
            
            // }
            // else
            // {
            // 	echo '<script>alert("Item Already Added")</script>';
            // }
       
            // }
            foreach ($_SESSION['shopping_cart'] as $key => $value) {
            $vaule_quan[]= $value["item_quantity"];
            }
            	echo (array_sum($vaule_quan));
        
            } else{

                foreach ($_SESSION['shopping_cart'] as $key => $value) {
            $vaule_quan[]= $value["item_quantity"];
            }
               echo (array_sum($vaule_quan));
               
            }
         ?>	 	</a></h3>
         <br />
         <br /><br />
         <?php
            $query = "SELECT * FROM tbl_product ORDER BY id ASC";
            $result = mysqli_query($connect, $query);
            if(mysqli_num_rows($result) > 0)
            {
            	while($row = mysqli_fetch_array($result))
            	{
            ?>
         <div class="col-md-4">
            <form method="POST" action="index.php?action=add&id=<?php echo $row["id"]; ?>">
               <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
                  <img src="images/<?php echo $row["image"]; ?>" class="img-responsive" /><br />
                  <h4 class="text-info"><?php echo $row["name"]; ?></h4>
                  <h4 class="text-danger">$ <?php echo $row["price"]; ?></h4>
                  <input type="text" name="quantity" value="" placeholder="0" class="form-control" />
                  <input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />
                  <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />
                  <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />
               </div>
            </form>
         </div>
         <?php
            }
            }
            ?>
      </div>
      </div>
      <br />
   
  
   </body>
</html>
		